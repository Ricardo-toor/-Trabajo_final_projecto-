# M7Spring

	Bootcamp Java Full Stack | Spring Módulo 7 |  Certificación Talento Digital
	
	Código del curso: BOTIC-SOFOF-22-02-13-0052
	
	Examen de certificación
	
	Plan de estudio: Desarrollo Aplicaciones Fullstack Java Trainee v2.0
	Anexo: Caso Homebanking Flex
	
# Desarrollador

	Etzel M. Valderrama
	etzelvalderrama@gmail.com
	
# Login

	Usuario: superadminetzel
	Contraseña: 999731.